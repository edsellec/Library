/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library.management;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Index {
    
    public void signup(String college, String idNumber, String pass) throws IOException {
        Index text = new Index();
        
        String user = idNumber+".txt";
        File file = new File("C:\\Library\\Users\\"+user);
        file.createNewFile();
        USER_FILE_NAME = "C:\\Library\\Users\\"+user;
        
        DateTimeFormatter date_time = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        
        List<String> lines = text.readSmallTextFile(FILE_NAME);
        lines.add(date_time.format(now));
        text.writeSmallTextFile(lines, FILE_NAME);
        
        text.readLargerTextFile(USER_FILE_NAME);
        lines = Arrays.asList(pass, college);
        text.writeLargerTextFile(USER_FILE_NAME, lines);
        
        lines = text.readSmallTextFile(USER_FILE_NAME);
        lines.add("\n");
        text.writeSmallTextFile(lines, USER_FILE_NAME);
    }
    
    public void history(String book, String idNumber, String condition) throws IOException {
        
        String user = idNumber+"_history.txt";
        USER_FILE_NAME = "C:\\Library\\Users\\History\\"+user;
        
        DateTimeFormatter date_time = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        File temp = new File(USER_FILE_NAME);
        if (temp.exists()){
            try(FileWriter fw = new FileWriter(USER_FILE_NAME, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw)) {
                out.print(date_time.format(now));
                out.print(";");
                out.print(idNumber);
                out.print(";");
                out.print(book);
                out.print(";");
                out.print(condition);
                out.print(";");
                out.println();
            } catch (IOException e) {
            //exception handling left as an exercise for the reader
            }
        }
        else {
            File file = new File("C:\\Library\\Users\\"+user);
            file.createNewFile();
            try(FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw)) {
                out.print(date_time.format(now));
                out.print(";");
                out.print(idNumber);
                out.print(";");
                out.print(book);
                out.print(";");
                out.println();
            } catch (IOException e) {
            //exception handling left as an exercise for the reader
            }
        }
    }
    
    public void storebook(String book, String author) throws IOException {
        Index text = new Index();
        
        DateTimeFormatter date_time = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        
        List<String> lines = text.readSmallTextFile(FILE_NAME);
        lines.add(date_time.format(now));
        text.writeSmallTextFile(lines, FILE_NAME);
        
        text.readLargerTextFile(LIB_FILE_NAME);
        lines = Arrays.asList(book, author);
        text.writeLargerTextFile(LIB_FILE_NAME, lines);
        
        lines = text.readSmallTextFile(USER_FILE_NAME);
        lines.add("\n");
        text.writeSmallTextFile(lines, USER_FILE_NAME);
    }
    
    public String checkpass(String file, String pass) throws IOException {
        String filePass = "";
        String readLine = null;
        FileReader reader = new FileReader(file);
        BufferedReader buffReader = new BufferedReader(reader);
        Index.Student student = new Index.Student();
        while((readLine = buffReader.readLine()) != null) {
            String[] splitData = readLine.split(";");

            student.setPass(splitData[0]);
            student.setCollege(splitData[1]);
        }
        filePass = student.getPass();
        return filePass;
    }
    
    class Student {

        private String pass;
        private String college;

        public String getPass() {
            return pass;
        }
        public void setPass(String pass) {
            this.pass = pass;
        }
        public String getCollege() {
            return college;
        }
        public void setCollege(String college) {
            this.college = college;
        }
    }
    
    final String FILE_NAME = "C:\\Library\\index.txt";
    String USER_FILE_NAME = "C:\\Library\\Users\\users.txt";
    final String LIB_FILE_NAME = "C:\\Library\\library.txt";
    final Charset ENCODING = StandardCharsets.UTF_8;
    
    //For smaller files
    /**
    Note: the javadoc of Files.readAllLines says it's intended for small
    files. But its implementation uses buffering, so it's likely good
    even for fairly large files.
    */
    List<String> readSmallTextFile(String aFileName) throws IOException {
        Path path = Paths.get(aFileName);
        return Files.readAllLines(path, ENCODING);
    }
    
    void writeSmallTextFile(List<String> aLines, String aFileName) throws IOException {
        Path path = Paths.get(aFileName);
        Files.write(path, aLines, ENCODING);
    }
    
    //For larger files
    void readLargerTextFile(String aFileName) throws IOException {
        Path path = Paths.get(aFileName);
        try (Scanner scanner = new Scanner(path, ENCODING.name())){
            while (scanner.hasNextLine()){
                
            //process each line in some way
            log(scanner.nextLine());
            }
        }
    }
    
    void readLargerTextFileAlternate(String aFileName) throws IOException {
        Path path = Paths.get(aFileName);
        try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)){
            String line = null;
            while ((line = reader.readLine()) != null) {
                
            //process each line in some way
            log(line);
            }
        }
    }
    
    void writeLargerTextFile(String aFileName, List<String> aLines) throws IOException {
        Path path = Paths.get(aFileName);
        try (BufferedWriter writer = Files.newBufferedWriter(path, ENCODING)){
            for(String line : aLines){
            writer.write(line);
            writer.write(";");
            }
        }
    }
    
    private static void log(Object aMsg){
        System.out.println(String.valueOf(aMsg));
    }
}